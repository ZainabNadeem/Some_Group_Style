# Automated end of day messages

## Overview

The Google app script in this project is designed to retrieve activity logs that are stored in a spreadsheet and
convert them into a description of the day's activities.

It utilizes data from the Trello webhook, the Slack API and the Open AI API.

## Instructions

I am providing this source code without instruction for the time being.

TBD
