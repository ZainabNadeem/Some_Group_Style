Useful Scripts
==============

A collection of scripts that make my life as a developer a little easier.


My favorite scripting language is bash.